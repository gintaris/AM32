# CMSIS-DSP

![GitHub release (latest by date including pre-releases)](https://img.shields.io/github/v/release/ARM-software/CMSIS-DSP?include_prereleases) ![GitHub](https://img.shields.io/github/license/ARM-software/CMSIS-DSP)

This CMSIS component has been moved into its own realm, please find it at [ARM-software/CMSIS-DSP](https://github.com/ARM-software/CMSIS-DSP).
